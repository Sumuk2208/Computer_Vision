from PIL import Image
import numpy as np
import matplotlib.pyplot as plt


def compare_images(image1_path, image2_path):
    # Open the two images
    img1 = Image.open(image1_path)
    img2 = Image.open(image2_path)

    # Convert images to grayscale (if they are not already)
    img1 = img1.convert("L")
    img2 = img2.convert("L")

    # Resize the images to the same size (if they are not already the same size)
    img1 = img1.resize(img2.size)

    # Convert images to numpy arrays
    img1_array = np.array(img1)
    img2_array = np.array(img2)

    # Calculate the total number of pixels
    total_pixels = img1_array.size

    # Count the matching pixels
    matching_pixels = np.sum(img1_array == img2_array)

    # Calculate the percentage of matching pixels
    percentage_matching = (matching_pixels / total_pixels) * 100

    # Calculate the difference (where pixels are not the same)
    difference = np.abs(img1_array - img2_array)

    # Display the difference image
    diff_image = Image.fromarray(difference)
    diff_image.show()

    # Return the percentage of matching pixels and the difference image
    return percentage_matching, difference


# Example usage:
image1_path = "gs.png"
image2_path = "my.png"
matching_percentage, difference = compare_images(image1_path, image2_path)
print(f"Percentage of matching pixels: {matching_percentage}%")

# Optionally, display the difference matrix
plt.imshow(difference, cmap="hot")
plt.title("Difference Image (Highlighted Differences)")
plt.show()
